function login() {
    // Get the input values
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    // Correct credentials
    const correctEmail = "sheoransourav29@gmail.com";
    const correctPassword = "sou123";

    // Check if the entered email and password match the correct ones
    if (email === correctEmail && password === correctPassword) {
        // If credentials are correct, redirect to 'main' page
        window.location.href = "/main";  // Redirect to 'main' page
        return false;  // Prevent form submission
    } else {
        // If credentials are incorrect, show an alert
        alert("Invalid email or password!");
        return false;  // Prevent form submission
    }
}
